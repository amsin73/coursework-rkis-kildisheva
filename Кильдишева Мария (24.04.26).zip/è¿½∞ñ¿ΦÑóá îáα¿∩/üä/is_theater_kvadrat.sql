-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 23 2026 г., 14:14
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `is_theater_kvadrat`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actor`
--

CREATE TABLE `actor` (
  `actor_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `biography` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` varchar(30) NOT NULL DEFAULT 'new',
  `total_amount` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `orderseat`
--

CREATE TABLE `orderseat` (
  `order_seat_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `seat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `play`
--

CREATE TABLE `play` (
  `play_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `genre` varchar(50) DEFAULT NULL,
  `duration_minutes` int(11) DEFAULT NULL,
  `base_price` decimal(15,0) NOT NULL DEFAULT 0,
  `poster_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `play`
--

INSERT INTO `play` (`play_id`, `title`, `description`, `genre`, `duration_minutes`, `base_price`, `poster_image`) VALUES
(1, 'Гамлет', 'Классическая постановка шекспировской трагедии. История о мести, безумии и власти, где призраки говорят правду, а принцы теряют рассудок.', 'Трагедия', 120, 500, 'hamlet_poster.jpg'),
(2, 'Анна Каренина', 'Драматическая адаптация романа Льва Толстого. История роковой страсти, разрушающей судьбы, на фоне блестящего петербургского света.', 'Драма', 150, 800, 'anna_karenina_poster.jpg'),
(3, 'Кафка на пляже', 'Сюрреалистичное путешествие по следам романа Харуки Мураками. Где кошки разговаривают, дождь падает вверх, а каждый ищет свою половину.', 'Магический реализм', 130, 700, 'kafka_poster.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `playactor`
--

CREATE TABLE `playactor` (
  `play_actor_id` int(11) NOT NULL,
  `play_id` int(11) NOT NULL,
  `actor_id` int(11) NOT NULL,
  `role` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `seat`
--

CREATE TABLE `seat` (
  `seat_id` int(11) NOT NULL,
  `play_id` int(11) NOT NULL,
  `seat_number` varchar(10) NOT NULL,
  `row` varchar(10) NOT NULL,
  `category` varchar(30) DEFAULT 'Standard',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) NOT NULL DEFAULT 'available',
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `payment_details` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`actor_id`);

--
-- Индексы таблицы `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `fk_order_user` (`user_id`);

--
-- Индексы таблицы `orderseat`
--
ALTER TABLE `orderseat`
  ADD PRIMARY KEY (`order_seat_id`),
  ADD UNIQUE KEY `uk_order_seat` (`order_id`,`seat_id`),
  ADD KEY `fk_oseat_seat` (`seat_id`);

--
-- Индексы таблицы `play`
--
ALTER TABLE `play`
  ADD PRIMARY KEY (`play_id`);

--
-- Индексы таблицы `playactor`
--
ALTER TABLE `playactor`
  ADD PRIMARY KEY (`play_actor_id`),
  ADD UNIQUE KEY `uk_play_actor` (`play_id`,`actor_id`),
  ADD KEY `fk_pa_actor` (`actor_id`);

--
-- Индексы таблицы `seat`
--
ALTER TABLE `seat`
  ADD PRIMARY KEY (`seat_id`),
  ADD KEY `fk_seat_play` (`play_id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `actor`
--
ALTER TABLE `actor`
  MODIFY `actor_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `orderseat`
--
ALTER TABLE `orderseat`
  MODIFY `order_seat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `play`
--
ALTER TABLE `play`
  MODIFY `play_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `playactor`
--
ALTER TABLE `playactor`
  MODIFY `play_actor_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `seat`
--
ALTER TABLE `seat`
  MODIFY `seat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orderseat`
--
ALTER TABLE `orderseat`
  ADD CONSTRAINT `fk_oseat_order` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_oseat_seat` FOREIGN KEY (`seat_id`) REFERENCES `seat` (`seat_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `playactor`
--
ALTER TABLE `playactor`
  ADD CONSTRAINT `fk_pa_actor` FOREIGN KEY (`actor_id`) REFERENCES `actor` (`actor_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pa_play` FOREIGN KEY (`play_id`) REFERENCES `play` (`play_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `seat`
--
ALTER TABLE `seat`
  ADD CONSTRAINT `fk_seat_play` FOREIGN KEY (`play_id`) REFERENCES `play` (`play_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
